#include "scenebasic_uniform.h"

#include <cstdio>
#include <cstdlib>

#include <string>
using std::string;

#include <iostream>
using std::cerr;
using std::endl;

#include "helper/glutils.h"

using glm::vec3;

SceneBasic_Uniform::SceneBasic_Uniform() : angle(0.0f) {}

void SceneBasic_Uniform::initScene()
{
    
    compile();
    skybox = new SkyBox();
    skyboxTexture = Texture::loadCubeMap("./media/skybox/sky",".jpg");

    spotLightPosition = glm::vec3(0, 5, 0);
    pointLightPositions = glm::vec3(0.7f, 0.2f, 2.0f);
    pointLightPosition2 = glm::vec3(0.7f, 0.15f, 2.0f);

    plane = new Plane(10,10,10,10,1,1);
    spot = ObjMesh::load("./media/spot_triangulated.obj");
    alphaTexture = Texture::loadTexture("./media/bluewater.png");
    spotTexture = Texture::loadTexture("./media/spot_texture.png");
    floorTexture = Texture::loadTexture("./media/brick1.jpg");
    alphaLeafTexture = Texture::loadTexture("./media/alphaLeaf.png");

    fence = ObjMesh::load("./media/fence.obj");
    fenceTexture = Texture::loadTexture("./media/fence.png");

    tree1 = ObjMesh::load("./media/garden_tree1.obj");
    treeTexture = Texture::loadTexture("./media/tree.png");

    std::cout << std::endl;
    camera = new Camera(glm::vec3(0.0f, 2.0f, 15.0f));
    prog.printActiveUniforms();

}

void SceneBasic_Uniform::compile()
{
    glEnable(GL_DEPTH_TEST);
	try {
		prog.compileShader("shader/basic_uniform.vert");
		prog.compileShader("shader/basic_uniform.frag");
		prog.link();
		prog.use();
	} catch (GLSLProgramException &e) {
		cerr << e.what() << endl;
		exit(EXIT_FAILURE);
	}

    try {
        progSky.compileShader("shader/skybox.vert");
        progSky.compileShader("shader/skybox.frag");
        progSky.link();
        progSky.use();
    }
    catch (GLSLProgramException& e) {
        cerr << e.what() << endl;
        exit(EXIT_FAILURE);
    }
}

void SceneBasic_Uniform::update( float t )
{
	//update your angle here
    float rotSpeed = 0.01;
    deltaTime = t - lastFrame;
    lastFrame = t;
    if (m_animate) {
        angle += rotSpeed * t;
        spotLightPosition.x = cos(t) * 5;
        spotLightPosition.z = sin(t) * 5;
        pointLightPositions.x = cos(t) * 5;
        pointLightPositions.z = cos(t) * 5;

        pointLightPosition2.x = sin(t) * 2.5;
        pointLightPosition2.z = sin(t) * 5;
    }
}

void SceneBasic_Uniform::render()
{
    glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
   
    prog.use();
    prog.setUniform("viewPos", camera->Position);
    prog.setUniform("screenSize", glm::vec2(width, height));
    prog.setUniform("material.shininess", 32.0f);
    prog.setUniform("sigma", 1.0f);

    prog.setUniform("material.diffuse", 0);
    prog.setUniform("material.alphaTexture", 1);

    // directional light
    prog.setUniform("dirLight.direction", -0.2f, -1.0f, -0.3f);
    prog.setUniform("dirLight.ambient", 0.05f, 0.05f, 0.05f);
    prog.setUniform("dirLight.diffuse", 0.8f, 0.8f, 0.8f);
    prog.setUniform("dirLight.specular", 0.5f, 0.5f, 0.5f);
    // point light 1
    prog.setUniform("pointLight.position", pointLightPositions);
    prog.setUniform("pointLight.ambient", 0.05f, 0.05f, 0.05f);
    prog.setUniform("pointLight.diffuse", 0.8f, 0.8f, 0.8f);
    prog.setUniform("pointLight.specular", 1.0f, 1.0f, 1.0f);
    prog.setUniform("pointLight.constant", 1.0f);
    prog.setUniform("pointLight.linear", 0.09f);
    prog.setUniform("pointLight.quadratic", 0.032f);

    // point light 1
    prog.setUniform("pointLight2.position", pointLightPosition2);
    prog.setUniform("pointLight2.ambient", 0.805f, 0.85f, 0.0f);
    prog.setUniform("pointLight2.diffuse", 0.8f, 0.8f, 0.0f);
    prog.setUniform("pointLight2.specular", 1.0f, 1.0f, 0.0f);
    prog.setUniform("pointLight2.constant", 1.0f);
    prog.setUniform("pointLight2.linear", 0.7f);
    prog.setUniform("pointLight2.quadratic", 1.8f);

    // spotLight
    prog.setUniform("spotLight.position", spotLightPosition);
    prog.setUniform("spotLight.direction", 0.0f, -1.0f, 0.0f);
    prog.setUniform("spotLight.ambient", 0.0f, 0.0f, 0.0f);
    prog.setUniform("spotLight.diffuse", 1.0f, 1.0f, 1.0f);
    prog.setUniform("spotLight.specular", 1.0f, 1.0f, 1.0f);
    prog.setUniform("spotLight.constant", 1.0f);
    prog.setUniform("spotLight.linear", 0.09f);
    prog.setUniform("spotLight.quadratic", 0.032f);
    prog.setUniform("spotLight.cutOff", glm::cos(glm::radians(12.5f)));
    prog.setUniform("spotLight.outerCutOff", glm::cos(glm::radians(15.0f)));

    // view/projection transformations
    glm::mat4 projection = glm::perspective(glm::radians(camera->Zoom), (float)width / (float)height, 0.1f, 100.0f);
    glm::mat4 view = camera->GetViewMatrix();
    prog.setUniform("projection", projection);
    prog.setUniform("view", view);

    // world transformation
    glm::mat4 model = glm::mat4(1.0f);
    prog.setUniform("model", model);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, alphaTexture);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, spotTexture);
    model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(-0.0f, -0.40f, -0.0f));
    model =  glm::rotate(model, glm::radians(angle), glm::vec3(0.0, 1.0, 0.0));
    prog.setUniform("model", model);
    
    spot->render();

    model = glm::mat4(1.0f);
   
    model = glm::translate(model, glm::vec3(-2.0f, -0.40f, -3.0f));
    model = glm::scale(model, glm::vec3(0.9));
    model = glm::rotate(model, glm::radians(180.0f), glm::vec3(0.0, 1.0, 0.0));
    prog.setUniform("model", model);

    spot->render();

    model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(0.0f, -1.0f, 0.0f));
    prog.setUniform("model", model);
    prog.setUniform("useMixColor", 1);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, floorTexture);

    plane->render();
    prog.setUniform("useMixColor", 0);

    model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(2.0f, 0.0f, -4.0f));
    model = glm::scale(model, glm::vec3(2.5, 2.5, 2.5));
    prog.setUniform("model", model);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, treeTexture);
    tree1->render();

    model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(3.0f, -.5f, -4.5f));
    model = glm::scale(model, glm::vec3(1.5, 1.5, 1.5));
    prog.setUniform("model", model);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, treeTexture);
    tree1->render();

    model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(4.0f, 1.0f, -4.0f));
    model = glm::scale(model, glm::vec3(2.5, 4.5, 2.5));
    prog.setUniform("model", model);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, treeTexture);
    tree1->render();


    model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(-4.0f, 1.0f, 4.0f));
    model = glm::scale(model, glm::vec3(4.5, 5.5, 4.5));
    prog.setUniform("model", model);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, treeTexture);
    tree1->render();

    

    model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(3.0f, 0.0f, 5.0f));
    model = glm::scale(model, glm::vec3(2.5, 2.5, 2.5));
    prog.setUniform("model", model);
    prog.setUniform("useAlphaLeaf", 1);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, treeTexture);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, alphaLeafTexture);
    tree1->render();
    prog.setUniform("useAlphaLeaf", 0);

    model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(4.0f, -.5f, 5.0f));
    model = glm::scale(model, glm::vec3(1.5, 1.5, 1.5));
    prog.setUniform("model", model);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, treeTexture);
    tree1->render();



    model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(0.0f, -.5f, -5.0f));
    model = glm::scale(model, glm::vec3(10, 2.5, 1));
    prog.setUniform("model", model);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, fenceTexture);
    fence->render();

    model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(0.0f, -.5f, 5.0f));
    model = glm::scale(model, glm::vec3(10, 2.5, 1));
    prog.setUniform("model", model);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, fenceTexture);
    fence->render();

    model = glm::mat4(1.0f);
    model = glm::rotate(model, glm::radians(90.0f), glm::vec3(0.0, 1.0, 0.0));
    model = glm::translate(model, glm::vec3(0.0f, -.5f, 5.0f));
    model = glm::scale(model, glm::vec3(10, 2.5, 1));
    
    prog.setUniform("model", model);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, fenceTexture);
    fence->render();

    model = glm::mat4(1.0f);
    model = glm::rotate(model, glm::radians(90.0f), glm::vec3(0.0, 1.0, 0.0));
    model = glm::translate(model, glm::vec3(0.0f, -.5f, -5.0f));
    model = glm::scale(model, glm::vec3(10, 2.5, 1));

    prog.setUniform("model", model);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, fenceTexture);
    fence->render();
    progSky.use();

    // draw skybox as last
    glDepthFunc(GL_LEQUAL);
   
    view = glm::mat4(glm::mat3(camera->GetViewMatrix()));
    progSky.setUniform("view", view);
    progSky.setUniform("projection", projection);
    // skybox cube
   
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_CUBE_MAP, skyboxTexture);
    skybox->render();
   
    glDepthFunc(GL_LESS);


    

}
void SceneBasic_Uniform::processMouseMovement(float xoffset, float yoffset)
{
    camera->ProcessMouseMovement(xoffset, yoffset);
}

void SceneBasic_Uniform::processKeyboard(int direction)
{
 
    if (direction == 0)
        camera->ProcessKeyboard(FORWARD, deltaTime);
    if (direction == 1)
        camera->ProcessKeyboard(BACKWARD, deltaTime);
    if (direction == 2)
        camera->ProcessKeyboard(LEFT, deltaTime);
    if (direction == 3)
        camera->ProcessKeyboard(RIGHT, deltaTime);
       
}
void SceneBasic_Uniform::resize(int w, int h)
{
    width = w;
    height = h;
    glViewport(0,0,w,h);
}
